/** @type {const} */
const themeColors = {
  primary: { light: '#5267D8', dark: '#8D9CFF' },
  accent: { light: '#EA6A47', dark: '#FF9674' },
  background: { light: '#F8F9FC', dark: '#111421' },
  surface: { light: '#FFFFFF', dark: '#1B2030' },
  foreground: { light: '#171A2B', dark: '#F4F5FF' },
  muted: { light: '#727890', dark: '#A8AEC5' },
  border: { light: '#E3E6F0', dark: '#30374D' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
