import { describe, expect, it } from "vitest";

import { filterByDateRange, formatDashboardAmount, totalSum } from "../lib/dashboard";

const entries = [
  { id: "1", name: "A", expression: "1000", result: "1000", createdAt: new Date(2026, 9, 1, 10).getTime() },
  { id: "2", name: "B", expression: "2,500", result: "2,500", createdAt: new Date(2026, 9, 5, 10).getTime() },
  { id: "3", name: "C", expression: "300", result: "300", createdAt: new Date(2026, 9, 10, 10).getTime() },
];

describe("dashboard totals", () => {
  it("filters dates inclusively", () => {
    expect(filterByDateRange(entries, "2026-10-05", "2026-10-10").map((entry) => entry.id)).toEqual(["2", "3"]);
  });

  it("sums saved results with comma formatting", () => {
    expect(totalSum(entries)).toBe(3800);
    expect(formatDashboardAmount(totalSum(entries))).toBe("3,800");
  });

  it("supports an open-ended date range", () => {
    expect(filterByDateRange(entries, "2026-10-05", "").map((entry) => entry.id)).toEqual(["2", "3"]);
  });
});
