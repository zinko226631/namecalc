import { describe, expect, it } from "vitest";

import { calculate, formatDisplayNumber, formatExpression, formatNumber } from "../lib/calculator";

describe("NameCalc calculator", () => {
  it("respects multiplication before addition", () => {
    expect(calculate("12+3×4")).toBe(24);
  });

  it("handles decimal and negative expressions", () => {
    expect(calculate("−5.5+2")).toBe(-3.5);
  });

  it("supports division and formats floating point output", () => {
    expect(formatNumber(calculate("10÷4"))).toBe("2.5");
  });

  it("ignores a trailing operator after a completed number", () => {
    expect(calculate("1000+2000+")).toBe(3000);
  });

  it("formats live totals and expression numbers with commas", () => {
    expect(formatDisplayNumber("18000")).toBe("18,000");
    expect(formatExpression("10000+2000+6000")).toBe("10,000+2,000+6,000");
  });

  it("rejects division by zero", () => {
    expect(() => calculate("8÷0")).toThrow();
  });
});
