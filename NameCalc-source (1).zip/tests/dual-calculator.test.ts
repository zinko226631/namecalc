import { describe, expect, it } from "vitest";

import { updateSlotAt, type CalculatorSlot } from "../lib/dual-calculator";

describe("dual calculators", () => {
  it("updates only the selected calculator slot", () => {
    const slots: CalculatorSlot[] = [
      { expression: "5+5", result: "10", justEvaluated: true },
      { expression: "600×5", result: "3000", justEvaluated: true },
    ];

    const next = updateSlotAt(slots, 0, { expression: "8+2", result: "10" });

    expect(next[0].expression).toBe("8+2");
    expect(next[0].result).toBe("10");
    expect(next[1]).toEqual(slots[1]);
  });
});
