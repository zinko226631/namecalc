import { describe, expect, it } from "vitest";

import {
  normalizeSavedCalculations,
  resolveSaveName,
  serializeSavedCalculations,
  STORAGE_VERSION,
} from "../lib/saved-calculations";

describe("saved calculator local storage", () => {
  const entry = {
    id: "1",
    name: "နေ့စဉ်ဝယ်ယူမှု",
    itemLabel: "ကြက်ဥ ၅ လုံး",
    expression: "600×5",
    result: "3000",
    createdAt: 123,
    items: [{ name: "ကြက်ဥ", quantity: 5, unitPrice: 600 }],
  };

  it("serializes entries with a storage version", () => {
    const payload = JSON.parse(serializeSavedCalculations([entry]));
    expect(payload.version).toBe(STORAGE_VERSION);
    expect(payload.items).toEqual([entry]);
  });

  it("loads both current payloads and legacy arrays", () => {
    expect(normalizeSavedCalculations({ version: STORAGE_VERSION, items: [entry] })).toEqual([entry]);
    expect(normalizeSavedCalculations([entry])).toEqual([entry]);
  });

  it("keeps valid entries and drops malformed records", () => {
    expect(normalizeSavedCalculations([entry, { name: "missing fields" }, null])).toEqual([entry]);
  });

  it("uses the first item or expression as a fallback save name", () => {
    expect(resolveSaveName("", "ခရမ်းချဉ်သီး", "", "2026-10-05")).toBe("ခရမ်းချဉ်သီး");
    expect(resolveSaveName("", "", "600×5", "2026-10-05")).toBe("တွက်ချက်မှု 2026-10-05");
  });
});
