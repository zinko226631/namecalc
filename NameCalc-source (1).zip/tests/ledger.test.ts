import { describe, expect, it } from "vitest";

import { itemLineTotal, itemsExpression, itemsTotal } from "../lib/ledger";

describe("multi-item ledger", () => {
  const items = [
    { name: "ကြက်ဥ", quantity: 5, unitPrice: 600 },
    { name: "နို့", quantity: 2, unitPrice: 1200 },
  ];

  it("calculates each item line", () => {
    expect(itemLineTotal(items[0])).toBe(3000);
  });

  it("calculates the combined total", () => {
    expect(itemsTotal(items)).toBe(5400);
  });

  it("builds a readable expression", () => {
    expect(itemsExpression(items)).toBe("600×5 + 1200×2");
  });
});
