import { describe, expect, it } from "vitest";

import { convertWeight, parseAmount, weightLabel } from "../lib/weight";

describe("Myanmar weight units", () => {
  it("converts one viss to one hundred kyattha", () => {
    expect(convertWeight(1, "ပိဿာ", "ကျပ်သား")).toBe(100);
    expect(convertWeight(100, "ကျပ်သား", "ပိဿာ")).toBe(1);
  });

  it("supports tomato at 1 viss × 3000", () => {
    const quantity = 1;
    const pricePerViss = 3000;
    expect(quantity * pricePerViss).toBe(3000);
    expect(weightLabel("ပိဿာ")).toBe("ပိဿာ");
  });

  it("parses fractions, decimals, and Myanmar digits", () => {
    expect(parseAmount("1/2")).toBe(0.5);
    expect(parseAmount("၁/၂")).toBe(0.5);
    expect(parseAmount("0.25")).toBe(0.25);
    expect(parseAmount("၂၅")).toBe(25);
  });
});
