import { describe, expect, it } from "vitest";

import { DEFAULT_APP_TITLE, normalizeAppTitle } from "../lib/app-title";

describe("app title", () => {
  it("trims and collapses whitespace", () => {
    expect(normalizeAppTitle("  My   Shop  ")).toBe("My Shop");
  });

  it("falls back to NameCalc for empty or invalid values", () => {
    expect(normalizeAppTitle("   ")).toBe(DEFAULT_APP_TITLE);
    expect(normalizeAppTitle(null)).toBe(DEFAULT_APP_TITLE);
  });

  it("limits very long titles", () => {
    expect(normalizeAppTitle("a".repeat(50))).toHaveLength(40);
  });
});
