import AsyncStorage from "@react-native-async-storage/async-storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { dateKeyFromTimestamp, filterByDateRange, formatDashboardAmount, totalSum } from "@/lib/dashboard";
import { normalizeSavedCalculations, STORAGE_KEY, type SavedCalculation } from "@/lib/saved-calculations";

function todayKey() {
  return dateKeyFromTimestamp(Date.now());
}

export default function DashboardScreen() {
  const colors = useColors();
  const [entries, setEntries] = useState<SavedCalculation[]>([]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const value = await AsyncStorage.getItem(STORAGE_KEY);
        if (active && value) setEntries(normalizeSavedCalculations(JSON.parse(value)));
      } catch {
        if (active) setEntries([]);
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  const filteredEntries = useMemo(
    () => filterByDateRange(entries, startDate.trim(), endDate.trim()),
    [entries, startDate, endDate],
  );
  const sum = totalSum(filteredEntries);
  const invalidRange = Boolean(startDate && endDate && startDate > endDate);

  const clearFilters = () => {
    setStartDate("");
    setEndDate("");
  };

  const setToday = () => {
    const today = todayKey();
    setStartDate(today);
    setEndDate(today);
  };

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right", "bottom"]}>
      <FlatList
        data={invalidRange ? [] : filteredEntries}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <View className="mb-6 flex-row items-center justify-between">
              <View>
                <Text className="text-3xl font-bold text-foreground">Dashboard</Text>
                <Text className="mt-1 text-sm text-muted">ရက်စွဲအလိုက် စုစုပေါင်းစာရင်း</Text>
              </View>
              <View className="h-11 w-11 items-center justify-center rounded-2xl bg-primary">
                <MaterialIcons name="insights" size={24} color="#FFFFFF" />
              </View>
            </View>

            <View className="rounded-3xl bg-surface p-5">
              <Text className="text-sm font-semibold text-foreground">ရက်စွဲ စစ်ထုတ်ရန်</Text>
              <Text className="mt-1 text-xs text-muted">ပုံစံ: YYYY-MM-DD (ဥပမာ 2026-10-05)</Text>
              <View className="mt-4 flex-row gap-3">
                <TextInput
                  value={startDate}
                  onChangeText={setStartDate}
                  placeholder="စတင်ရက်"
                  placeholderTextColor={colors.muted}
                  style={[styles.dateInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
                  autoCapitalize="none"
                  keyboardType="numbers-and-punctuation"
                />
                <TextInput
                  value={endDate}
                  onChangeText={setEndDate}
                  placeholder="ပြီးဆုံးရက်"
                  placeholderTextColor={colors.muted}
                  style={[styles.dateInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
                  autoCapitalize="none"
                  keyboardType="numbers-and-punctuation"
                />
              </View>
              <View className="mt-3 flex-row gap-3">
                <Pressable onPress={setToday} style={({ pressed }) => [styles.filterButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}>
                  <Text style={styles.filterButtonText}>ယနေ့</Text>
                </Pressable>
                <Pressable onPress={clearFilters} style={({ pressed }) => [styles.filterButton, { borderColor: colors.border }, pressed && styles.pressed]}>
                  <Text className="font-semibold text-muted">အားလုံးပြ</Text>
                </Pressable>
              </View>
              {invalidRange ? <Text className="mt-3 text-sm text-error">စတင်ရက်က ပြီးဆုံးရက်ထက် မကျော်ရပါ။</Text> : null}
            </View>

            <View className="mt-5 flex-row gap-3">
              <View className="flex-1 rounded-3xl bg-primary p-5">
                <Text className="text-sm text-white/80">စုစုပေါင်း (Total Sum)</Text>
                <Text numberOfLines={1} adjustsFontSizeToFit className="mt-2 text-3xl font-bold text-white">{formatDashboardAmount(sum)}</Text>
              </View>
              <View className="flex-1 rounded-3xl bg-surface p-5">
                <Text className="text-sm text-muted">စာရင်းအရေအတွက်</Text>
                <Text className="mt-2 text-3xl font-bold text-foreground">{filteredEntries.length}</Text>
              </View>
            </View>

            <View className="mb-3 mt-8">
              <Text className="text-xl font-bold text-foreground">စာရင်းအသေးစိတ်</Text>
              <Text className="mt-1 text-sm text-muted">ရွေးထားတဲ့ရက်စွဲအတွင်း သိမ်းထားတာများ</Text>
            </View>
          </View>
        }
        ListEmptyComponent={
          <View className="items-center rounded-2xl border border-dashed border-border px-5 py-7">
            <MaterialIcons name="event-note" size={28} color={colors.muted} />
            <Text className="mt-2 text-center text-sm text-muted">
              {invalidRange ? "ရက်စွဲအပိုင်းအခြား မမှန်ပါ" : "ဒီရက်စွဲအတွင်း စာရင်းမရှိသေးပါ"}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={[styles.entryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View className="mr-3 h-10 w-10 items-center justify-center rounded-xl bg-primary/15">
              <MaterialIcons name="receipt-long" size={19} color={colors.primary} />
            </View>
            <View className="flex-1">
              <Text numberOfLines={1} className="font-semibold text-foreground">{item.itemLabel || item.name}</Text>
              <Text numberOfLines={1} className="mt-1 text-sm text-muted">{item.expression} = {item.result}</Text>
              <Text className="mt-1 text-xs text-muted">{dateKeyFromTimestamp(item.createdAt)}</Text>
            </View>
            <Text className="ml-2 font-bold text-primary">{formatDashboardAmount(Number(item.result.replaceAll(",", "")))}</Text>
          </View>
        )}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 12, paddingBottom: 28 },
  dateInput: { flex: 1, minHeight: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, fontSize: 14 },
  filterButton: { flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 14 },
  filterButtonText: { color: "#FFFFFF", fontWeight: "700" },
  entryCard: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 19, padding: 13, marginBottom: 10 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.97 }] },
});
