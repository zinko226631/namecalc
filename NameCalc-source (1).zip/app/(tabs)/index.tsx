import AsyncStorage from "@react-native-async-storage/async-storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useEffect, useMemo, useState } from "react";
import {
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { calculate, formatDisplayNumber, formatExpression, formatNumber } from "@/lib/calculator";
import { APP_TITLE_STORAGE_KEY, DEFAULT_APP_TITLE, normalizeAppTitle } from "@/lib/app-title";
import { updateSlotAt, type CalculatorSlot } from "@/lib/dual-calculator";
import { itemsExpression, itemsTotal } from "@/lib/ledger";
import { ITEM_UNITS, parseAmount, weightLabel } from "@/lib/weight";
import {
  normalizeSavedCalculations,
  resolveSaveName,
  serializeSavedCalculations,
  STORAGE_KEY,
  type SavedItem,
  type SavedCalculation,
} from "@/lib/saved-calculations";

type KeyKind = "number" | "operator" | "action" | "equals";

const keypad = [
  ["AC", "⌫", "%", "÷"],
  ["7", "8", "9", "×"],
  ["4", "5", "6", "−"],
  ["1", "2", "3", "+"],
  ["0", ".", "="],
];

const emptyItem = (): SavedItem => ({ name: "", quantity: 1, unitPrice: 0, unit: "ခု" });

export default function HomeScreen() {
  const colors = useColors();
  const [calculators, setCalculators] = useState<CalculatorSlot[]>([
    { expression: "", result: "0", justEvaluated: false },
    { expression: "", result: "0", justEvaluated: false },
  ]);
  const [activeCalculator, setActiveCalculator] = useState(0);
  const [saved, setSaved] = useState<SavedCalculation[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [itemLines, setItemLines] = useState<SavedItem[]>([emptyItem()]);
  const [quantityDrafts, setQuantityDrafts] = useState<Record<number, string>>({});
  const [saveName, setSaveName] = useState("");
  const [saveError, setSaveError] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [appTitle, setAppTitle] = useState(DEFAULT_APP_TITLE);
  const [titleDraft, setTitleDraft] = useState(DEFAULT_APP_TITLE);
  const [showTitleModal, setShowTitleModal] = useState(false);

  const { expression, result, justEvaluated } = calculators[activeCalculator];

  const updateActiveCalculator = (patch: Partial<CalculatorSlot> | ((current: CalculatorSlot) => CalculatorSlot)) => {
    setCalculators((current) => typeof patch === "function"
      ? current.map((slot, index) => index === activeCalculator ? patch(slot) : slot)
      : updateSlotAt(current, activeCalculator, patch));
  };

  useEffect(() => {
    let active = true;
    Promise.all([AsyncStorage.getItem(STORAGE_KEY), AsyncStorage.getItem(APP_TITLE_STORAGE_KEY)])
      .then(([value, savedTitle]) => {
        if (!active) return;
        if (value) {
          try {
            setSaved(normalizeSavedCalculations(JSON.parse(value)));
          } catch {
            setSaved([]);
          }
        }
        const normalizedTitle = normalizeAppTitle(savedTitle);
        setAppTitle(normalizedTitle);
        setTitleDraft(normalizedTitle);
      })
      .catch(() => {
        if (active) setSaved([]);
      });
    return () => {
      active = false;
    };
  }, []);

  const keyColors = useMemo(
    () =>
      ({
        number: { backgroundColor: colors.surface, color: colors.foreground },
        operator: { backgroundColor: colors.primary, color: "#FFFFFF" },
        action: { backgroundColor: colors.border, color: colors.foreground },
        equals: { backgroundColor: "#EA6A47", color: "#FFFFFF" },
      }) as Record<KeyKind, { backgroundColor: string; color: string }>,
    [colors],
  );

  const persist = (next: SavedCalculation[]) => {
    setSaved(next);
    void AsyncStorage.setItem(STORAGE_KEY, serializeSavedCalculations(next)).catch(() => {
      console.warn("NameCalc: local storage write failed");
    });
  };

  const saveAppTitle = () => {
    const nextTitle = normalizeAppTitle(titleDraft);
    setAppTitle(nextTitle);
    setTitleDraft(nextTitle);
    setShowTitleModal(false);
    void AsyncStorage.setItem(APP_TITLE_STORAGE_KEY, nextTitle).catch(() => {
      console.warn("NameCalc: title storage write failed");
    });
  };

  const filteredSaved = saved.filter((item) => {
    const query = searchQuery.trim().toLocaleLowerCase();
    if (!query) return true;
    return `${item.name} ${item.itemLabel ?? ""} ${item.expression}`.toLocaleLowerCase().includes(query);
  });

  const updateLiveResult = (nextExpression: string) => {
    try {
      updateActiveCalculator({ result: formatNumber(calculate(nextExpression)) });
    } catch {
      updateActiveCalculator({ result: "Error" });
    }
  };

  const handleKey = (key: string) => {
    Keyboard.dismiss();
    if (key === "AC") {
      updateActiveCalculator({ expression: "", result: "0", justEvaluated: false });
      return;
    }
    if (key === "⌫") {
      updateActiveCalculator((current) => ({ ...current, expression: current.expression.slice(0, -1), justEvaluated: false }));
      return;
    }
    if (key === "%") {
      try {
        const percentage = calculate(expression || result) / 100;
        updateActiveCalculator({ expression: formatNumber(percentage), result: formatNumber(percentage), justEvaluated: false });
      } catch {
        updateActiveCalculator({ result: "Error", justEvaluated: false });
      }
      return;
    }
    if (key === "=") {
      if (!expression) return;
      try {
        updateActiveCalculator({ result: formatNumber(calculate(expression)), justEvaluated: true });
      } catch {
        updateActiveCalculator({ result: "Error" });
      }
      return;
    }
    if (/\d/.test(key) || key === ".") {
      const startsFresh = justEvaluated || result === "Error";
      const current = startsFresh ? "" : expression;
      const lastPart = current.split(/[+−×÷]/).pop() ?? "";
      if (key === "." && lastPart.includes(".")) return;
      const next = current === "0" ? key : current + key;
      updateActiveCalculator({ expression: next, justEvaluated: false });
      updateLiveResult(next);
      return;
    }
    const isOperator = ["+", "−", "×", "÷"].includes(key);
    if (isOperator) {
      const current = justEvaluated ? result : expression;
      if (!current && key !== "−") return;
      if (/[+−×÷]$/.test(current)) {
        const next = current.slice(0, -1) + key;
        updateActiveCalculator({ expression: next, justEvaluated: false });
        updateLiveResult(next);
      } else {
        const next = current + key;
        updateActiveCalculator({ expression: next, justEvaluated: false });
        updateLiveResult(next);
      }
    }
  };

  const saveCurrent = () => {
    const validItems = itemLines.filter(
      (item) => item.name.trim() && Number.isFinite(item.quantity) && item.quantity > 0 && Number.isFinite(item.unitPrice) && item.unitPrice >= 0,
    );
    const hasItems = validItems.length > 0;
    const trimmed = resolveSaveName(saveName, validItems[0]?.name ?? "", expression, new Date().toLocaleDateString());
    if (!trimmed) {
      setSaveError("ပစ္စည်းအမည် သို့မဟုတ် တွက်ချက်မှုတစ်ခု ထည့်ပေးပါ");
      return;
    }
    if (!expression && !hasItems) {
      setSaveError("သိမ်းရန် ပစ္စည်းတစ်မျိုး ထည့်ပါ သို့မဟုတ် calculator နဲ့ အရင်တွက်ပါ");
      return;
    }
    if (!hasItems && result === "Error") {
      setSaveError("တွက်ချက်မှု မမှန်သေးပါ။ ဂဏန်းနဲ့ operator တွေကို ပြန်စစ်ပါ");
      return;
    }
    const savedExpression = hasItems ? itemsExpression(validItems) : expression;
    const savedResult = hasItems ? formatNumber(itemsTotal(validItems)) : result;
    const entry: SavedCalculation = {
      id: editingId ?? `${Date.now()}`,
      name: trimmed,
      itemLabel: hasItems ? validItems.map((item) => `${item.name.trim()} ${item.quantity} ${weightLabel(item.unit)}`).join(", ") : "",
      expression: savedExpression,
      result: savedResult,
      createdAt: editingId ? saved.find((item) => item.id === editingId)?.createdAt ?? Date.now() : Date.now(),
      items: hasItems ? validItems : undefined,
    };
    persist(editingId ? saved.map((item) => item.id === editingId ? entry : item) : [entry, ...saved]);
    setItemLines([emptyItem()]);
    setQuantityDrafts({});
    setSaveName("");
    setSaveError("");
    setEditingId(null);
    setShowSaveModal(false);
  };

  const beginNewSave = () => {
    setEditingId(null);
    setSaveName("");
    setSaveError("");
    setItemLines([emptyItem()]);
    setQuantityDrafts({});
    setShowSaveModal(true);
  };

  const updateItemLine = (index: number, patch: Partial<SavedItem>) => {
    setItemLines((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, ...patch } : item));
  };

  const addItemLine = () => {
    if (itemLines.length < 20) setItemLines((current) => [...current, emptyItem()]);
  };

  const removeItemLine = (index: number) => {
    setItemLines((current) => current.length === 1 ? [emptyItem()] : current.filter((_, itemIndex) => itemIndex !== index));
  };

  const openSaved = (entry: SavedCalculation) => {
    updateActiveCalculator({ expression: entry.expression, result: entry.result, justEvaluated: true });
  };

  const beginEdit = (entry: SavedCalculation) => {
    setEditingId(entry.id);
    setSaveName(entry.name);
    updateActiveCalculator({ expression: entry.expression, result: entry.result, justEvaluated: true });
    const editItems = entry.items?.length ? entry.items : [{ name: entry.itemLabel ?? "", quantity: 1, unitPrice: Number(entry.result.replaceAll(",", "")) || 0, unit: "ခု" as const }];
    setItemLines(editItems);
    setQuantityDrafts(Object.fromEntries(editItems.map((item, index) => [index, String(item.quantity)])));
    setShowSaveModal(true);
  };

  const deleteSaved = (entry: SavedCalculation) => {
    persist(saved.filter((item) => item.id !== entry.id));
  };

  const renderKey = (key: string) => {
    const kind: KeyKind =
      key === "="
        ? "equals"
        : ["+", "−", "×", "÷"].includes(key)
          ? "operator"
          : ["AC", "⌫", "%"].includes(key)
            ? "action"
            : "number";
    return (
      <Pressable
        key={key}
        onPress={() => handleKey(key)}
        style={({ pressed }) => [
          styles.key,
          key === "0" && styles.zeroKey,
          { backgroundColor: keyColors[kind].backgroundColor },
          pressed && styles.pressed,
        ]}
        accessibilityLabel={`calculator ${key}`}
      >
        {key === "⌫" ? (
          <MaterialIcons name="backspace" size={22} color={keyColors[kind].color} />
        ) : (
          <Text style={[styles.keyText, { color: keyColors[kind].color }]}>{key}</Text>
        )}
      </Pressable>
    );
  };

  const calculatorHeader = (
    <View>
      <View className="mb-6 flex-row items-center justify-between">
        <View className="flex-1">
          <Pressable
            onPress={() => { setTitleDraft(appTitle); setShowTitleModal(true); }}
            style={({ pressed }) => [styles.titleButton, pressed && styles.iconPressed]}
            accessibilityLabel="edit app title"
          >
            <Text numberOfLines={1} className="text-3xl font-bold text-foreground">{appTitle}</Text>
            <MaterialIcons name="edit" size={18} color={colors.muted} />
          </Pressable>
          <Text className="mt-1 text-sm text-muted">နာမည်တပ်ပြီး တွက်ချက်မှုတွေ သိမ်းထားပါ</Text>
        </View>
          <View className="h-11 w-11 items-center justify-center rounded-2xl bg-primary">
            <MaterialIcons name="calculate" size={24} color="#FFFFFF" />
          </View>
        </View>

        <View className="mb-3 flex-row gap-2">
          {[0, 1].map((calculatorIndex) => (
            <Pressable
              key={calculatorIndex}
              onPress={() => setActiveCalculator(calculatorIndex)}
              style={({ pressed }) => [
                styles.calculatorTab,
                { backgroundColor: activeCalculator === calculatorIndex ? colors.primary : colors.surface, borderColor: colors.border },
                pressed && styles.pressed,
              ]}
              accessibilityLabel={`calculator ${calculatorIndex + 1}`}
            >
              <MaterialIcons name="calculate" size={16} color={activeCalculator === calculatorIndex ? "#FFFFFF" : colors.muted} />
              <Text style={{ color: activeCalculator === calculatorIndex ? "#FFFFFF" : colors.foreground, fontWeight: "700" }}>
                တွက်စက် {calculatorIndex + 1}
              </Text>
              {calculators[calculatorIndex].expression ? <Text style={{ color: activeCalculator === calculatorIndex ? "#FFFFFF" : colors.muted }}> • ရှိ</Text> : null}
            </Pressable>
          ))}
        </View>

      <View className="rounded-[28px] bg-surface p-5">
        <Text numberOfLines={1} className="text-right text-base text-muted">
            {expression ? formatExpression(expression) : "အသစ်တွက်မယ်"}
        </Text>
        <Text numberOfLines={1} className="mt-2 text-right text-5xl font-semibold text-foreground">
          {formatDisplayNumber(result)}
        </Text>
        <View className="mt-5 gap-3">
          {keypad.map((row) => (
            <View key={row.join("")} className="flex-row gap-3">
              {row.map(renderKey)}
            </View>
          ))}
        </View>
      </View>

      <View className="mb-3 mt-8 flex-row items-center justify-between">
        <View>
          <Text className="text-xl font-bold text-foreground">သိမ်းထားတာများ</Text>
          <Text className="mt-1 text-sm text-muted">အမည်နဲ့ ပြန်ရှာပြီး အသုံးပြုနိုင်ပါတယ်</Text>
        </View>
        <Pressable
            onPress={beginNewSave}
            style={({ pressed }) => [styles.saveButton, { backgroundColor: "#EA6A47" }, pressed && styles.pressed]}
          >
            <MaterialIcons name="playlist-add" size={18} color="#FFFFFF" />
            <Text style={styles.saveButtonText}>စာရင်းထည့်</Text>
          </Pressable>
      </View>
      <View className="mb-4 flex-row items-center rounded-2xl border border-border bg-surface px-3">
        <MaterialIcons name="search" size={21} color={colors.muted} />
        <TextInput
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="သိမ်းထားတဲ့နာမည်ကို ရှာပါ"
          placeholderTextColor={colors.muted}
          returnKeyType="search"
          autoCorrect={false}
          style={[styles.searchInput, { color: colors.foreground }]}
          accessibilityLabel="saved calculation search"
        />
        {searchQuery ? (
          <Pressable
            onPress={() => setSearchQuery("")}
            hitSlop={10}
            style={({ pressed }) => [styles.clearSearch, pressed && styles.iconPressed]}
            accessibilityLabel="clear saved calculation search"
          >
            <MaterialIcons name="close" size={19} color={colors.muted} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );

  return (
    <ScreenContainer className="px-5" edges={["top", "left", "right", "bottom"]}>
      <FlatList
        data={filteredSaved}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={calculatorHeader}
        ListEmptyComponent={
          <View className="items-center rounded-2xl border border-dashed border-border px-5 py-7">
            <MaterialIcons name={searchQuery ? "search-off" : "bookmark-border"} size={28} color={colors.muted} />
            <Text className="mt-2 text-center text-sm text-muted">
              {searchQuery ? "ရှာဖွေမှုနဲ့ ကိုက်ညီတာ မတွေ့ပါ" : "သိမ်းထားတဲ့တွက်ချက်မှု မရှိသေးပါ"}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={[styles.savedCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Pressable
              onPress={() => openSaved(item)}
              style={({ pressed }) => [styles.savedContent, pressed && styles.pressed]}
              accessibilityRole="button"
              accessibilityLabel={`open ${item.name}`}
            >
            <View className="flex-1">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <MaterialIcons name="receipt-long" size={18} color={colors.primary} />
                  <Text numberOfLines={1} className="ml-2 font-bold text-foreground">{item.name}</Text>
                </View>
                <Text className="text-xs text-muted">{new Date(item.createdAt).toLocaleDateString()}</Text>
              </View>
              {item.items?.length ? (
                <View className="mt-1">
                  {item.items.map((savedItem, itemIndex) => (
                    <Text key={`${item.id}-item-${itemIndex}`} numberOfLines={1} className="text-sm font-medium text-primary">
                      {savedItem.name}   {savedItem.quantity} {weightLabel(savedItem.unit)} × {formatDisplayNumber(String(savedItem.unitPrice))} = {formatDisplayNumber(String(savedItem.quantity * savedItem.unitPrice))}
                    </Text>
                  ))}
                </View>
              ) : item.itemLabel ? (
                <Text numberOfLines={1} className="mt-1 text-sm font-medium text-primary">{item.itemLabel}</Text>
              ) : null}
              <View className="mt-2 border-t border-dashed border-border pt-2">
                <Text numberOfLines={1} className="text-xs text-muted">စုစုပေါင်း</Text>
                <Text numberOfLines={1} className="text-lg font-bold text-primary">{formatDisplayNumber(item.result)}</Text>
              </View>
            </View>
            </Pressable>
            <Pressable
              onPress={() => beginEdit(item)}
              hitSlop={12}
              style={({ pressed }) => [styles.iconButton, pressed && styles.iconPressed]}
              accessibilityLabel={`edit ${item.name}`}
            >
              <MaterialIcons name="edit" size={19} color={colors.primary} />
            </Pressable>
            <Pressable
              onPress={() => deleteSaved(item)}
              hitSlop={12}
              style={({ pressed }) => [styles.iconButton, pressed && styles.iconPressed]}
              accessibilityLabel={`delete ${item.name}`}
            >
              <MaterialIcons name="delete-outline" size={20} color={colors.muted} />
            </Pressable>
          </View>
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />

      <Modal visible={showSaveModal} transparent animationType="fade" onRequestClose={() => setShowSaveModal(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setShowSaveModal(false)}>
          <KeyboardAvoidingView behavior="padding" style={styles.keyboardAvoiding}>
            <Pressable
              style={[styles.modalCard, { backgroundColor: colors.background }]}
              onPress={(event) => event.stopPropagation()}
            >
            <Text className="text-xl font-bold text-foreground">{editingId ? "သိမ်းထားတာကို ပြင်မယ်" : "တွက်ချက်မှုကို အမည်တပ်ပါ"}</Text>
            <Text className="mt-2 text-sm text-muted">နောက်မှ ပြန်သုံးရလွယ်အောင် မှတ်ထားမယ့်နာမည်</Text>
            <TextInput
              autoFocus
              value={saveName}
              onChangeText={(value) => { setSaveName(value); setSaveError(""); }}
              onSubmitEditing={saveCurrent}
              returnKeyType="done"
              placeholder="ဥပမာ - ဇန်နဝါရီ အိမ်လခ"
              placeholderTextColor={colors.muted}
              style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
            />
            {saveError ? <Text className="mt-2 text-sm font-semibold text-error">{saveError}</Text> : null}
            <View className="mt-4 flex-row items-center justify-between">
              <View>
                <Text className="text-sm font-semibold text-foreground">ပစ္စည်းစာရင်း (အများဆုံး ၂၀ မျိုး)</Text>
                <Text className="mt-1 text-xs text-muted">ဥပမာ - ခရမ်းချဉ်သီး၊ ၁၊ ပိဿာ၊ ၃၀၀၀</Text>
              </View>
              <Text className="text-sm font-semibold text-primary">{itemLines.length}/20</Text>
            </View>
            <ScrollView style={styles.itemList} keyboardShouldPersistTaps="handled">
              {itemLines.map((item, index) => (
                <View key={`item-${index}`} style={[styles.itemRow, { borderColor: colors.border, backgroundColor: colors.surface }]}>
                  <View style={styles.itemTopRow}>
                    <Text className="font-bold text-foreground">ပစ္စည်း {index + 1}</Text>
                    <Pressable onPress={() => removeItemLine(index)} hitSlop={8} style={({ pressed }) => [styles.removeItem, pressed && styles.iconPressed]}>
                      <MaterialIcons name="close" size={18} color={colors.muted} />
                    </Pressable>
                  </View>
                  <Text className="mt-2 text-xs font-semibold text-muted">အမျိုးအမည်</Text>
                  <TextInput
                    value={item.name}
                    onChangeText={(value) => updateItemLine(index, { name: value })}
                    placeholder="ဥပမာ - ကြက်ဥ"
                    placeholderTextColor={colors.muted}
                    style={[styles.itemNameInput, { color: colors.foreground, borderColor: colors.border }]}
                  />
                  <View className="mt-2 flex-row items-center justify-between">
                    <Text className="text-xs font-semibold text-muted">အလေးချိန်/အရေအတွက် ယူနစ်</Text>
                    <Pressable
                      onPress={() => {
                        const currentIndex = ITEM_UNITS.indexOf(item.unit ?? "ခု");
                        updateItemLine(index, { unit: ITEM_UNITS[(currentIndex + 1) % ITEM_UNITS.length] });
                      }}
                      style={({ pressed }) => [styles.unitButton, { borderColor: colors.primary }, pressed && styles.pressed]}
                    >
                      <Text className="font-bold text-primary">{weightLabel(item.unit)} ပြောင်းရန်</Text>
                    </Pressable>
                  </View>
                  <View style={styles.itemNumberRow}>
                    <View style={styles.itemNumberField}>
                      <Text className="text-xs font-semibold text-muted">အရေအတွက် ({weightLabel(item.unit)})</Text>
                      <TextInput
                        value={quantityDrafts[index] ?? (item.quantity === 1 && !item.name ? "" : String(item.quantity))}
                        onChangeText={(value) => {
                          setQuantityDrafts((current) => ({ ...current, [index]: value }));
                          const parsed = parseAmount(value);
                          if (parsed !== null && parsed >= 0) updateItemLine(index, { quantity: parsed });
                        }}
                        placeholder="ဥပမာ - ၁/၂၊ ၂၅"
                        placeholderTextColor={colors.muted}
                        keyboardType="default"
                        style={[styles.smallInput, { color: colors.foreground, borderColor: colors.border }]}
                      />
                    </View>
                    <View style={styles.itemNumberField}>
                      <Text className="text-xs font-semibold text-muted">တစ်ခုဈေးနှုန်း</Text>
                      <TextInput
                        value={item.unitPrice ? String(item.unitPrice) : ""}
                        onChangeText={(value) => updateItemLine(index, { unitPrice: Number(value) || 0 })}
                        placeholder="ဥပမာ - ၆၀၀"
                        placeholderTextColor={colors.muted}
                        keyboardType="decimal-pad"
                        style={[styles.smallInput, { color: colors.foreground, borderColor: colors.border }]}
                      />
                    </View>
                    <View style={styles.lineTotal}>
                      <Text className="text-xs text-muted">စုစုပေါင်း</Text>
                      <Text className="font-bold text-primary">{formatDisplayNumber(formatNumber(item.quantity * item.unitPrice))}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </ScrollView>
            <View className="mt-2 flex-row items-center justify-between">
              <Pressable onPress={addItemLine} disabled={itemLines.length >= 20} style={({ pressed }) => [styles.addItemButton, itemLines.length >= 20 && styles.disabled, pressed && styles.pressed]}>
                <MaterialIcons name="add" size={18} color={colors.primary} />
                <Text className="font-semibold text-primary">ပစ္စည်းထပ်ထည့်</Text>
              </Pressable>
              <Text className="font-bold text-primary">စုစုပေါင်း: {formatDisplayNumber(formatNumber(itemsTotal(itemLines.filter((item) => item.name.trim() && item.quantity > 0))))}</Text>
            </View>
            <View className="mt-4 flex-row gap-3">
              <Pressable
                onPress={() => { setShowSaveModal(false); setEditingId(null); }}
                style={({ pressed }) => [styles.modalButton, { borderColor: colors.border }, pressed && styles.pressed]}
              >
                <Text className="font-semibold text-muted">မလုပ်တော့ဘူး</Text>
              </Pressable>
              <Pressable
                onPress={saveCurrent}
                style={({ pressed }) => [styles.modalButton, { backgroundColor: "#EA6A47" }, pressed && styles.pressed]}
              >
                <Text style={styles.saveButtonText}>{editingId ? "ပြင်ပြီးသိမ်းမယ်" : "သိမ်းမယ်"}</Text>
              </Pressable>
            </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>

      <Modal visible={showTitleModal} transparent animationType="fade" onRequestClose={() => setShowTitleModal(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setShowTitleModal(false)}>
          <KeyboardAvoidingView behavior="padding" style={styles.keyboardAvoiding}>
            <Pressable
              style={[styles.modalCard, { backgroundColor: colors.background }]}
              onPress={(event) => event.stopPropagation()}
            >
              <Text className="text-xl font-bold text-foreground">အပေါ်က ခေါင်းစဉ်ပြင်မယ်</Text>
              <Text className="mt-2 text-sm text-muted">ဥပမာ - မိသားစုကုန်ကျစရိတ်၊ ဆိုင်စာရင်း၊ ကြက်ဥဆိုင်</Text>
              <TextInput
                autoFocus
                value={titleDraft}
                onChangeText={setTitleDraft}
                placeholder="ခေါင်းစဉ်ရေးပါ"
                placeholderTextColor={colors.muted}
                maxLength={40}
                onSubmitEditing={saveAppTitle}
                returnKeyType="done"
                style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]}
              />
              <View className="mt-4 flex-row gap-3">
                <Pressable
                  onPress={() => setShowTitleModal(false)}
                  style={({ pressed }) => [styles.modalButton, { borderColor: colors.border }, pressed && styles.pressed]}
                >
                  <Text className="font-semibold text-muted">မလုပ်တော့ဘူး</Text>
                </Pressable>
                <Pressable
                  onPress={saveAppTitle}
                  style={({ pressed }) => [styles.modalButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}
                >
                  <Text style={styles.saveButtonText}>သိမ်းမယ်</Text>
                </Pressable>
              </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { paddingTop: 12, paddingBottom: 28 },
  key: { flex: 1, minHeight: 60, alignItems: "center", justifyContent: "center", borderRadius: 19 },
  zeroKey: { flex: 2.08 },
  keyText: { fontSize: 22, fontWeight: "700" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.97 }] },
  saveButton: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 10 },
  saveButtonText: { color: "#FFFFFF", fontWeight: "700", fontSize: 13 },
  titleButton: { flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "flex-start", maxWidth: "100%" },
  calculatorTab: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderWidth: 1, borderRadius: 12, paddingVertical: 9 },
  savedCard: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 19, padding: 13, marginBottom: 10 },
  savedContent: { flex: 1, flexDirection: "row", alignItems: "center" },
  iconButton: { padding: 4 },
  iconPressed: { opacity: 0.45 },
  modalBackdrop: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(15,23,42,0.45)", padding: 22 },
  keyboardAvoiding: { width: "100%", alignItems: "center" },
  modalCard: { width: "100%", maxWidth: 420, maxHeight: "92%", borderRadius: 24, padding: 22 },
  input: { marginTop: 18, borderWidth: 1, borderRadius: 14, paddingHorizontal: 15, paddingVertical: 13, fontSize: 16 },
  itemList: { maxHeight: 300, marginTop: 10 },
  itemRow: { borderWidth: 1, borderRadius: 13, padding: 10, marginBottom: 8 },
  itemTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  itemNameInput: { minHeight: 40, marginTop: 5, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, fontSize: 14 },
  unitButton: { borderWidth: 1, borderRadius: 9, paddingHorizontal: 9, paddingVertical: 5 },
  itemNumberRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, marginTop: 8 },
  itemNumberField: { flex: 1 },
  smallInput: { minHeight: 38, marginTop: 4, borderWidth: 1, borderRadius: 10, paddingHorizontal: 7, textAlign: "center", fontSize: 13 },
  lineTotal: { minWidth: 64, alignItems: "flex-end", paddingBottom: 8 },
  removeItem: { padding: 5 },
  addItemButton: { flexDirection: "row", alignItems: "center", gap: 4, paddingVertical: 8 },
  disabled: { opacity: 0.4 },
  searchInput: { flex: 1, minHeight: 48, paddingHorizontal: 10, fontSize: 14 },
  clearSearch: { padding: 4 },
  modalButton: { flex: 1, minHeight: 46, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 14 },
});
