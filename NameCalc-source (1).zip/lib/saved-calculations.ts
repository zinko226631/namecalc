export type ItemUnit = "ခု" | "ကျပ်သား" | "ပိဿာ";

export type SavedItem = {
  name: string;
  quantity: number;
  unitPrice: number;
  unit?: ItemUnit;
};

export type SavedCalculation = {
  id: string;
  name: string;
  itemLabel?: string;
  expression: string;
  result: string;
  createdAt: number;
  items?: SavedItem[];
};

export const STORAGE_KEY = "namecalc.saved-calculations";
export const STORAGE_VERSION = 1;

export function resolveSaveName(saveName: string, firstItemName: string, expression: string, dateLabel: string) {
  return saveName.trim() || firstItemName.trim() || (expression ? `တွက်ချက်မှု ${dateLabel}` : "");
}

type StoredPayload = {
  version: number;
  items: unknown;
};

export function normalizeSavedCalculations(value: unknown): SavedCalculation[] {
  const items =
    value && typeof value === "object" && "version" in value && "items" in value
      ? (value as StoredPayload).items
      : value;
  if (!Array.isArray(items)) return [];

  return items.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const candidate = item as Partial<SavedCalculation>;
    if (
      typeof candidate.id !== "string" ||
      typeof candidate.name !== "string" ||
      typeof candidate.expression !== "string" ||
      typeof candidate.result !== "string"
    ) {
      return [];
    }
    return [{
      id: candidate.id,
      name: candidate.name,
      itemLabel: typeof candidate.itemLabel === "string" ? candidate.itemLabel : "",
      expression: candidate.expression,
      result: candidate.result,
      createdAt: typeof candidate.createdAt === "number" ? candidate.createdAt : Date.now(),
      items: Array.isArray(candidate.items)
        ? candidate.items.flatMap((item) => {
            if (!item || typeof item !== "object") return [];
            const savedItem = item as Partial<SavedItem>;
            return typeof savedItem.name === "string" && typeof savedItem.quantity === "number" && typeof savedItem.unitPrice === "number"
              ? [{
                  name: savedItem.name,
                  quantity: savedItem.quantity,
                  unitPrice: savedItem.unitPrice,
                  ...(savedItem.unit === "ကျပ်သား" || savedItem.unit === "ပိဿာ" || savedItem.unit === "ခု" ? { unit: savedItem.unit } : {}),
                }]
              : [];
          })
        : undefined,
    }];
  });
}

export function serializeSavedCalculations(items: SavedCalculation[]) {
  return JSON.stringify({ version: STORAGE_VERSION, items });
}
