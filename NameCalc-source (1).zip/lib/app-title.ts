export const DEFAULT_APP_TITLE = "NameCalc";
export const APP_TITLE_STORAGE_KEY = "namecalc.app-title.v1";

export function normalizeAppTitle(value: unknown) {
  if (typeof value !== "string") return DEFAULT_APP_TITLE;
  const title = value.trim().replace(/\s+/g, " ");
  return title.slice(0, 40) || DEFAULT_APP_TITLE;
}
