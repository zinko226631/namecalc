import type { SavedItem } from "./saved-calculations";

export function itemLineTotal(item: Pick<SavedItem, "quantity" | "unitPrice">) {
  return item.quantity * item.unitPrice;
}

export function itemsTotal(items: SavedItem[]) {
  return items.reduce((sum, item) => sum + itemLineTotal(item), 0);
}

export function itemsExpression(items: SavedItem[]) {
  return items.map((item) => `${item.unitPrice}×${item.quantity}${item.unit ? ` ${item.unit}` : ""}`).join(" + ");
}
