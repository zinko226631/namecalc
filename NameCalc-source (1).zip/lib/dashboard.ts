import type { SavedCalculation } from "./saved-calculations";

export function dateKeyFromTimestamp(timestamp: number) {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function filterByDateRange(
  entries: SavedCalculation[],
  startDate: string,
  endDate: string,
) {
  return entries.filter((entry) => {
    const key = dateKeyFromTimestamp(entry.createdAt);
    return (!startDate || key >= startDate) && (!endDate || key <= endDate);
  });
}

export function totalSum(entries: SavedCalculation[]) {
  return entries.reduce((sum, entry) => {
    const amount = Number(entry.result.replaceAll(",", ""));
    return Number.isFinite(amount) ? sum + amount : sum;
  }, 0);
}

export function formatDashboardAmount(value: number) {
  return value.toLocaleString("en-US", { maximumFractionDigits: 8 });
}
