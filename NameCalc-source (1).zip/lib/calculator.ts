export function calculate(rawExpression: string): number {
  const expression = rawExpression
    .replaceAll("×", "*")
    .replaceAll("÷", "/")
    .replaceAll("−", "-")
    .replace(/[+\-*/]+$/, "");
  if (!expression) throw new Error("empty");
  const tokens = expression.match(/\d*\.?\d+|[+\-*/]/g) ?? [];
  if (!tokens.length) throw new Error("empty");

  const values: number[] = [];
  const operators: string[] = [];
  const precedence: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2 };

  const applyTop = () => {
    const operator = operators.pop();
    const right = values.pop();
    const left = values.pop();
    if (!operator || right === undefined || left === undefined) throw new Error("invalid");
    if (operator === "+") values.push(left + right);
    if (operator === "-") values.push(left - right);
    if (operator === "*") values.push(left * right);
    if (operator === "/") {
      if (right === 0) throw new Error("divide");
      values.push(left / right);
    }
  };

  let previousWasOperator = true;
  tokens.forEach((token) => {
    if (!Number.isNaN(Number(token))) {
      values.push(Number(token));
      previousWasOperator = false;
      return;
    }
    if (token === "-" && previousWasOperator) values.push(0);
    while (
      operators.length &&
      precedence[operators[operators.length - 1]] >= precedence[token]
    ) {
      applyTop();
    }
    operators.push(token);
    previousWasOperator = true;
  });

  while (operators.length) applyTop();
  const answer = values[0];
  if (answer === undefined || !Number.isFinite(answer)) throw new Error("invalid");
  return answer;
}

export function formatNumber(value: number) {
  return Number(value.toFixed(8)).toString();
}

export function formatDisplayNumber(value: string) {
  if (value === "Error" || value === "") return value;
  const number = Number(value);
  return Number.isFinite(number) ? number.toLocaleString("en-US", { maximumFractionDigits: 8 }) : value;
}

export function formatExpression(rawExpression: string) {
  return rawExpression.replace(/\d+(?:\.\d+)?/g, (part) =>
    Number(part).toLocaleString("en-US", { maximumFractionDigits: 8 }),
  );
}
