import type { ItemUnit } from "./saved-calculations";

export const ITEM_UNITS: ItemUnit[] = ["ခု", "ကျပ်သား", "ပိဿာ"];

const KYATTHA_PER_UNIT: Record<ItemUnit, number> = {
  "ခု": 1,
  "ကျပ်သား": 1,
  "ပိဿာ": 100,
};

export function convertWeight(value: number, from: ItemUnit, to: ItemUnit) {
  return value * KYATTHA_PER_UNIT[from] / KYATTHA_PER_UNIT[to];
}

export function weightLabel(unit: ItemUnit | undefined) {
  return unit ?? "ခု";
}

export function parseAmount(value: string) {
  const normalized = value
    .trim()
    .replace(/[၀-၉]/g, (digit) => String("၀၁၂၃၄၅၆၇၈၉".indexOf(digit)));
  if (!normalized) return null;
  if (/^\d+(?:\.\d+)?\s*\/\s*\d+(?:\.\d+)?$/.test(normalized)) {
    const [numerator, denominator] = normalized.split("/").map((part) => Number(part.trim()));
    if (!denominator) return null;
    const result = numerator / denominator;
    return Number.isFinite(result) ? result : null;
  }
  const result = Number(normalized);
  return Number.isFinite(result) ? result : null;
}
