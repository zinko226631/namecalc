export type CalculatorSlot = { expression: string; result: string; justEvaluated: boolean };

export function updateSlotAt(
  slots: CalculatorSlot[],
  index: number,
  patch: Partial<CalculatorSlot>,
) {
  return slots.map((slot, slotIndex) => slotIndex === index ? { ...slot, ...patch } : slot);
}
